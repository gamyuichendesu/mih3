# MIH Connect v5 · Prototype (ไฟล์เดียว สำหรับ GitHub + Vercel)

ต้นแบบระบบ MIH Connect v5 · ไม่มีหน้าแรก / Log in / ลงทะเบียน · เปิดมาอยู่ในระบบทันที · สลับโมดูลที่แท็บด้านบน · ข้อมูลทั้งหมดเป็นข้อมูลสมมุติ · ไม่มี backend

เว็บทั้งหมดอยู่ใน **`index.html` ไฟล์เดียว** (รวมโลโก้ ภาพประกอบ ไฟล์ตัวอย่าง .xlsx และ React ไว้ข้างในแล้ว)
จึงไม่มีโฟลเดอร์ย่อยให้อัปโหลดตกหล่น

## ไฟล์ที่ต้องมีใน repo
| ไฟล์ | จำเป็น |
|---|---|
| `index.html` | ✅ ตัวเว็บ |
| `vercel.json` | ✅ ตั้งค่า noindex และให้ทุก URL เปิดหน้าเว็บ |
| `README.md`, `.gitignore` | ไม่จำเป็น |

## ขึ้น GitHub
**ผ่านหน้าเว็บ:** เปิด repo → Add file → Upload files → ลาก `index.html` และ `vercel.json` → Commit changes
(ถ้า repo มีไฟล์เก่าอยู่ เช่น `support.js`, รูป .png/.jpg ที่ root, โฟลเดอร์ `vendor/` `assets/` ลบทิ้งได้ เว็บใหม่ไม่ใช้แล้ว)

**ผ่าน git:** โฟลเดอร์นี้ commit ไว้แล้ว
```bash
git remote add origin https://github.com/<บัญชี>/mih-connect-v5.git
git push -u origin main          # repo ใหม่ที่ยังว่าง
# ถ้า repo เดิมมีไฟล์อยู่แล้วและต้องการแทนที่ทั้งหมด:  git push -u origin main --force
```

## Deploy Vercel
vercel.com/new → Import repo → Framework Preset: **Other** · Build Command: เว้นว่าง → **Deploy**
(ถ้า Import ไว้แล้ว แค่ commit ไฟล์ใหม่ Vercel จะ deploy ให้เอง)

## หมายเหตุ
- ฟอนต์ Inter + IBM Plex Sans Thai โหลดจาก Google Fonts
- ตั้ง noindex และมีป้าย "Prototype · ข้อมูลสมมุติ" ที่ขอบล่าง
- จำกัดคนดูได้ที่ Vercel → Settings → Deployment Protection
